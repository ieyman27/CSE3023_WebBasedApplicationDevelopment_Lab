<%-- 
    Document   : footer
    Created on : 21 Apr 2026, 3:02:30 pm
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<hr>
<div style="text-align:center;">
    <p>&copy; 2026 UMT Health System</p>
</div>

