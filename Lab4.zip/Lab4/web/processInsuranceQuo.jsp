<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // 1. Retrieve data from the request
    String icNo = request.getParameter("icNo");
    String name = request.getParameter("name");
    double marketPrice = Double.parseDouble(request.getParameter("marketPrice"));
    String coverageType = request.getParameter("coverageType");
    double ncdPercentage = Double.parseDouble(request.getParameter("ncd"));

    // 2. Perform Calculations (Based on logic shown in Figure 4.21)
    // Base Insurance calculation (e.g., 5% of market price)
    double baseInsurance = marketPrice * 0.05; 
    
    // NCD Discount
    double ncdDiscount = baseInsurance * (ncdPercentage / 100);
    
    // Total After NCD
    double afterNcd = baseInsurance - ncdDiscount;
    
    // SST (8%)
    double sst = afterNcd * 0.08;
    
    // Final Amount
    double finalAmount = afterNcd + sst;
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            width: 450px;
        }
        h2 {
            color: #333;
            font-size: 1.2em;
            margin-bottom: 25px;
            border-left: 5px solid #6a1b9a;
            padding-left: 10px;
            margin-top: 0;
        }
        .label {
            font-weight: bold;
            font-size: 0.9em;
            color: #444;
            margin-top: 15px;
        }
        .value {
            font-size: 0.95em;
            color: #333;
            margin-bottom: 10px;
            margin-top: 5px;
        }
        hr {
            border: 0;
            border-top: 1px solid #333;
            margin: 20px 0;
        }
        .total-row {
            font-weight: bold;
        }
        .back-btn {
            margin-top: 20px;
            padding: 8px 25px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.85em;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Insurance Quotation Result</h2>
    
    <div class="label">IC No:</div>
    <div class="value"><%= icNo %></div>

    <div class="label">Name:</div>
    <div class="value"><%= name %></div>

    <div class="label">Market Price (RM):</div>
    <div class="value"><%= String.format("%.2f", marketPrice) %></div>

    <div class="label">Coverage Type:</div>
    <div class="value"><%= coverageType %></div>

    <div class="label">NCD:</div>
    <div class="value"><%= (int)ncdPercentage %>%</div>

    <hr>

    <div class="label">Base Insurance:</div>
    <div class="value">RM <%= String.format("%.2f", baseInsurance) %></div>

    <div class="label">NCD Discount:</div>
    <div class="value">RM <%= String.format("%.2f", ncdDiscount) %></div>

    <div class="label">After NCD:</div>
    <div class="value">RM <%= String.format("%.2f", afterNcd) %></div>

    <div class="label">SST (8%):</div>
    <div class="value">RM <%= String.format("%.2f", sst) %></div>

    <div class="label">Final Insurance Amount:</div>
    <div class="value total-row">RM <%= String.format("%.2f", finalAmount) %></div>

    <button class="back-btn" onclick="history.back()">Back</button>
</div>

</body>
</html>