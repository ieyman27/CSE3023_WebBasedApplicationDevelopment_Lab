<%-- 
    Document   : header
    Created on : 21 Apr 2026, 3:02:23 pm
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
    <div style="background:#6a0dad;color:white;padding:10px;">
    <h2>UMT Healthy Lifestyle Program</h2>
    <a href="bmiCalculator.jsp" style="color:white;margin-right:15px;">BMI Calculator</a>
    <a href="healthInfo.jsp" style="color:white;">Health Info</a>
</div>
<hr>
