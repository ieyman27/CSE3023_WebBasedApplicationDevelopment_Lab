<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Customer Discount Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            width: 400px;
            margin: 80px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #6a0dad;
        }
        .btn {
            margin-top: 15px;
        }
    </style>
</head>
<body>

<%
    String custCode = request.getParameter("custCode");
    int quantity = Integer.parseInt(request.getParameter("quantity"));
    int custType = Integer.parseInt(request.getParameter("custType"));

    double pricePerUnit = 10.0; // assume RM10 per item
    double total = quantity * pricePerUnit;
    double discount = 0;
    String typeName = "";
    String status = "";

    if (custType == 1) {
        typeName = "Normal Customer";
        discount = 0.10; // 10%
    } else if (custType == 2) {
        typeName = "Privilege Customer";
        discount = 0.25; // 25%
    }

    double finalAmount = total - (total * discount);
    status = "You're entitled to " + (int)(discount * 100) + "% discount";
%>

<div class="container">
    <h2>Customer Discount Result</h2>

    <h3>Transaction Summary</h3>

    <p><b>Customer Code:</b><br><%= custCode %></p>

    <p><b>Quantity:</b><br><%= quantity %></p>

    <p><b>Customer Type:</b><br><%= typeName %></p>

    <p><b>Status:</b><br><%= status %></p>

    <p><b>Total Amount:</b><br>
        RM <%= String.format("%.2f", finalAmount) %>
    </p>

    <div class="btn">
        <a href="customer.html">
            <button>Back</button>
        </a>
    </div>
</div>

</body>
</html>