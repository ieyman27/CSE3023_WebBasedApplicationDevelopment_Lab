<%-- 
    Document   : processBMI
    Created on : 21 Apr 2026, 3:06:55 pm
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
            String w = request.getParameter("weight");
            String h = request.getParameter("height");

            double weight = Double.parseDouble(w);
            double height = Double.parseDouble(h);

            if (height == 0) {
                out.println("Height cannot be zero!");
                return;
            }

            double bmi = weight / (height * height);

            String category = "";
            if (bmi < 18.5)
                category = "Underweight";
            else if (bmi <= 25)
                category = "Normal";
            else
                category = "Overweight";
        %>

        <jsp:forward page="resultBMI.jsp">
            <jsp:param name="bmi" value="<%= bmi%>" />
            <jsp:param name="category" value="<%= category%>" />
        </jsp:forward>
    </body>
</html>
