<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 3:09:22 pm
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@ page import="java.util.ArrayList" %>
        <%@ include file="header.jsp" %>

        <h3>Health Information</h3>

        <%
            ArrayList<String> categories = new ArrayList<>();
            categories.add("Underweight (< 18.5)");
            categories.add("Normal (18.5 - 25)");
            categories.add("Overweight (> 25)");
        %>

        <table border="1" cellpadding="10">
            <tr>
                <th>BMI Category</th>
            </tr>

            <%
                for (String c : categories) {
            %>
            <tr>
                <td><%= c%></td>
            </tr>
            <%
                }
            %>
        </table>

        <%@ include file="footer.jsp" %>
    </body>
</html>
