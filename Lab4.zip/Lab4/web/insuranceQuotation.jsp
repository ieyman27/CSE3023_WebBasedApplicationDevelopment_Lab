<%-- 
    Document   : insuranceQuotation
    Created on : 21 Apr 2026, 2:53:58 pm
    Author     : User
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }
        .container {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            width: 450px;
            border: 1px solid #ddd;
        }
        h2 {
            color: #333;
            font-size: 1.2em;
            margin-bottom: 20px;
            border-left: 5px solid #6a1b9a; /* Purple accent seen in image */
            padding-left: 10px;
        }
        fieldset {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
        }
        legend {
            font-size: 0.9em;
            color: #666;
            padding: 0 5px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
            font-size: 0.85em;
            margin-bottom: 5px;
        }
        input[type="text"], input[type="number"], select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box; /* Ensures padding doesn't affect width */
        }
        .button-group {
            margin-top: 20px;
        }
        input[type="submit"] {
            background-color: #f0f0f0;
            border: 1px solid #bbb;
            padding: 5px 15px;
            cursor: pointer;
            border-radius: 3px;
        }
        input[type="button"] {
            background-color: #f0f0f0;
            border: 1px solid #bbb;
            padding: 5px 15px;
            cursor: pointer;
            border-radius: 3px;
            margin-left: 5px;
        }
        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Insurance Quotation</h2>
    
    <form action="processInsuranceQuo.jsp" method="POST">
        <fieldset>
            <legend>Insurance Calculation</legend>
            
            <div class="form-group">
                <label for="icNo">IC No*</label>
                <input type="text" id="icNo" name="icNo" placeholder="E.g. 021213-05-3478" required>
            </div>

            <div class="form-group">
                <label for="name">Name*</label>
                <input type="text" id="name" name="name" placeholder="Enter name" required>
            </div>

            <div class="form-group">
                <label for="marketPrice">Market Price*</label>
                <input type="number" id="marketPrice" name="marketPrice" placeholder="Price" step="0.01" required>
            </div>

            <div class="form-group">
                <label for="coverageType">Coverage Type</label>
                <select id="coverageType" name="coverageType">
                    <option value="Third Party">Third Party</option>
                    <option value="Comprehensive">Comprehensive</option>
                </select>
            </div>

            <div class="form-group">
                <label for="ncd">No Claims Discount (NCD)</label>
                <select id="ncd" name="ncd">
                    <option value="0">0%</option>
                    <option value="25">25%</option>
                    <option value="30">30%</option>
                    <option value="38.3">38.3%</option>
                    <option value="45">45%</option>
                    <option value="55">55%</option>
                </select>
            </div>

            <div class="button-group">
                <input type="submit" value="Submit">
                <input type="button" value="Cancel" onclick="window.location.reload();">
            </div>
            
        </fieldset>
    </form>
</div>

</body>
</html>