<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head>
    <title>Currency Conversion Result</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f2f2f2;
        }
        .container {
            width: 400px;
            margin: 80px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #6a0dad;
        }
    </style>
</head>
<body>

<%
    double amount = Double.parseDouble(request.getParameter("amount"));
    int currency = Integer.parseInt(request.getParameter("currency"));

    double rate = 0;
    String currencyName = "";

    // Example exchange rates
    switch(currency) {
        case 1:
            currencyName = "USD";
            rate = 0.21;
            break;
        case 2:
            currencyName = "EURO";
            rate = 0.19;
            break;
        case 3:
            currencyName = "JPY";
            rate = 30.0;
            break;
        case 4:
            currencyName = "SGD";
            rate = 0.31;
            break;
    }

    double converted = amount * rate;
%>

<div class="container">
    <h2>Currency Conversion Result</h2>

    <p><b>Amount (RM):</b><br><%= amount %></p>

    <p><b>Converted To:</b><br><%= currencyName %></p>

    <p><b>Converted Amount:</b><br>
        <%= String.format("%.2f", converted) %> <%= currencyName %>
    </p>

    <br>
    <a href="currencyConversion.html">
        <button>Back</button>
    </a>
</div>

</body>
</html>