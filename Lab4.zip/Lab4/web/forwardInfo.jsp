<%-- 
    Document   : fowardInfo
    Created on : 21 Apr 2026, 2:48:17 pm
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            width: 400px;
            margin: 80px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #6a0dad;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        .radio-group {
            margin-top: 10px;
        }
        .buttons {
            margin-top: 15px;
            text-align: center;
        }
        button {
            padding: 8px 15px;
            margin: 5px;
        }
        </style>
    </head>
    
    <body>
        <%
            String name = request.getParameter("uname");
            String email = request.getParameter("email");
            String nationality = request.getParameter("nationality");
            String background = request.getParameter("background");
        %>
        
        <p>Name: <%= name%></p>
        <p>Email: <%= email%></p>
        <p>Nationality: <%= nationality%></p>
        <p>Background: <%= background%></p>
    </body>
</html>
