<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI Result</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>

        <%
            // 1. Retrieve the BMI value passed from the previous page via <jsp:param>
            // We parse it to a double to perform the category logic check
            String bmiParam = request.getParameter("bmi");
            double bmi = (bmiParam != null) ? Double.parseDouble(bmiParam) : 0.0;

            // 2. Determine the category based on the logic provided
            String category;
            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi >= 18.5 && bmi <= 25) {
                category = "Normal";
            } else {
                category = "Overweight";
            }
        %>

        <h3>BMI Result</h3>

        <p>
            <b>Your BMI:</b> 
            <%-- Displaying formatted output to 2 decimal places using JSP Expression --%>
            <%= String.format("%.2f", bmi) %>
        </p>

        <p>
            <b>Category:</b> 
            <%-- Displaying the category using JSP Expression --%>
            <%= category %>
        </p>

        <%@ include file="footer.jsp" %>
    </body>
</html>