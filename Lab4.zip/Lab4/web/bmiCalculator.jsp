<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 3:02:46 pm
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>

<h3>BMI Calculator</h3>

<form action="processBMI.jsp" method="post">
    Weight (kg): <br>
    <input type="number" name="weight" step="0.1" required><br><br>

    Height (m): <br>
    <input type="number" name="height" step="0.01" required><br><br>

    <button type="submit">Calculate BMI</button>
</form>

<%@ include file="footer.jsp" %>
