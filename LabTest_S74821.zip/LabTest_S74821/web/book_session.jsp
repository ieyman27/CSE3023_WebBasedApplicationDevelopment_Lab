<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 4:03:04 PM
    Author     : MP2-4
--%>

<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/sql" prefix="sql" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/xml" prefix="x" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Book Session View</title>
    </head>
    <body>
        <h1>Book Session<h1>
                <p> Session_id : <%= request.getParameter("session_id")%></p><!-- comment -->
                <p> Student_name : <%= request.getParameter("student_name")%></p>
                <p> Branch_location : <%= request.getParameter("branch_location")%></p><!-- comment -->
                <p> Lesson_type : <%= request.getParameter("lesson_type")%></p><!-- comment -->
                <p> Status : <%= request.getParameter("status")%></p>
    </body>
</html>
