<%-- 
    Document   : footer
    Created on : 16 Jun 2026, 4:44:31 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<hr>
<div style ="text-align : center;">
    <p>&copy; 2026 Web Lab Test </p>
</div>
