/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;

/**
 *
 * @author MP2-4
 */
public class ScheduleServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ScheduleServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ScheduleServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     PrintWriter out = response.getWriter();
     out.println("<h6> Session List</h6>");
     out.println("<table border='1'><tr><th>session_id</th><th>student_name</th><th>branch_location</th><th>lesson_type</th><th>status</th></tr>");
     
     try{
         Class.forName("com.mysql.cj.jdbc.Driver");
         Connection conn = DriverManager.getConnection("jdbc:mysql://loclhost:3306//driversmart_db","root", "");
         Statement stmt = conn.createStatement();
         ResultSet rs =stmt.executeQuery("SELECT * FROM Tranning_Sessions");
         while (rs.next())
         {
             int session_id = rs.getInt("session_id");
             out.println("<tr>");
             out.println("<td>" + session_id + "</td>" );
             
             out.println("<td>" + rs.getString("student_name") + "</td>");
             out.println("<td>" + rs.getString("branch_location") + "</td>");
             out.println("<td>" + rs.getString("lesson_type") + "</td>");
             out.println("<td>" + rs.getString("status") + "</td>"); 
             out.println("<td><a href= 'UpdateServlet'?session_id=" + session_id + "'> Edit</a>| ");
             out.println("<a href='DeletServlet?session_id=" + session_id + "'>Delete</a></td> ");
             out.println("</tr>");    
         }
         out.println("</table>");
         out.println("<br><a href = 'index.html'> Add New Student Name</a>");
         rs.close();
         stmt.close();
         conn.close();
        }
     catch (Exception e) 
     {
         e.printStackTrace();
     }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
