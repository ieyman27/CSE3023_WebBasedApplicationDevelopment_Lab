/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
public class SessionDAO 
{
    private static final String URL = "jdbc:mysql://localhost:3306/drivesmart_db";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
    public static Connection getConnection()
    {
        Connection conn = null;
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
                    conn = DriverManager.getConnection(URL,USER,PASSWORD);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
            
            return conn;
    }   
}
