package SessionBean;

public class SessionBean {

    private int session_id;
    private String student_name;
    private String branch_location;
    private String lesson_type;
    private String status;

    //Empty Constructor 
    public SessionBean() {
    }

    //Getter and Setter
    //session_id
    public int getsession_id() {
        return session_id;
    }

    public void setsession_id(int session_id) {
        this.session_id = session_id;
    }

    //student_name
    public String getstudent_name() {
        return student_name;
    }

    public void setstudent_name(String student_name) {
        this.student_name = student_name;
    }

    //branch_location
    public String getbranch_location() {
        return branch_location;
    }

    public void setbranch_location(String branch_location) {
        this.branch_location = branch_location;
    }

    //lesson_type
    public String getlesson_type() {
        return lesson_type;
    }

    public void setlesson_type(String leson_type) {
        this.lesson_type = lesson_type;
    }

    //status
    public String getstatus() {
        return status;
    }

    public void setstatus(String status) {
        this.status = status;
    }
}
