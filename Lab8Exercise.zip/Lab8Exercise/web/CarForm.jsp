<%-- 
    Document   : CarForm
    Created on : 2 Jun 2026, 2:41:38 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Car Shop Application</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    </head>
    <body>
        <nav class="navbar navbar-expand-md navbar-dark" style="background-color: #343a40">
            <a href="" class="navbar-brand">Car Shop App</a>
            <ul class="navbar-nav">
                <li><a href="<%=request.getContextPath()%>/list" class="nav-link">Cars</a></li>
            </ul>
        </nav>
        <br>
        <div class="container col-md-5">
            <div class="card">
                <div class="card-body">
                    <c:if test="${car != null}">
                        <form action="update" method="post">
                        </c:if>
                        <c:if test="${car == null}">
                            <form action="insert" method="post">
                            </c:if>

                            <h2 class="text-center">
                                <c:if test="${car != null}">Edit Car</c:if>
                                <c:if test="${car == null}">Add New Car</c:if>
                                </h2>
                                <hr>

                            <c:if test="${car != null}">
                                <input type="hidden" name="id" value="<c:out value='${car.car_id}' />" />
                            </c:if>

                            <div class="form-group">
                                <label>Brand</label>
                                <input type="text" value="<c:out value='${car.brand}' />" class="form-control" name="brand" required="required">
                            </div>

                            <div class="form-group">
                                <label>Model</label>
                                <input type="text" value="<c:out value='${car.model}' />" class="form-control" name="model" required="required">
                            </div>

                            <div class="form-group">
                                <label>Cylinders</label>
                                <input type="number" value="<c:out value='${car.cyclinder}' />" class="form-control" name="cyclinder" required="required">
                            </div>

                            <div class="form-group">
                                <label>Price</label>
                                <input type="number" step="0.01" value="<c:out value='${car.price}' />" class="form-control" name="price" required="required">
                            </div>

                            <button type="submit" class="btn btn-success btn-block">Save</button>
                        </form>
                </div>
            </div>
        </div>
    </body>
</html>
