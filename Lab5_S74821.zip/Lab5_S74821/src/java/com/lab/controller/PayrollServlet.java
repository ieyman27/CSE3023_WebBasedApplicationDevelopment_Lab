package com.lab.controller;

import com.lab.bean.Employee;
import java.io.IOException;
import java.util.ArrayList;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/PayrollServlet")
public class PayrollServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<Employee> list = new ArrayList<>();

        // Create employees
        Employee e1 = new Employee();
        e1.setEmpId("E001");
        e1.setName("Alice");
        e1.setDepartment("HR");
        e1.setBasicSalary(3500);

        Employee e2 = new Employee();
        e2.setEmpId("E002");
        e2.setName("Bob");
        e2.setDepartment("IT");
        e2.setBasicSalary(2800);

        Employee e3 = new Employee();
        e3.setEmpId("E003");
        e3.setName("Charlie");
        e3.setDepartment("Finance");
        e3.setBasicSalary(4000);

        Employee e4 = new Employee();
        e4.setEmpId("E004");
        e4.setName("Diana");
        e4.setDepartment("Marketing");
        e4.setBasicSalary(2500);

        Employee e5 = new Employee();
        e5.setEmpId("E005");
        e5.setName("Evan");
        e5.setDepartment("Sales");
        e5.setBasicSalary(3200);

        // Add to list
        list.add(e1);
        list.add(e2);
        list.add(e3);
        list.add(e4);
        list.add(e5);

        // Send to JSP
        request.setAttribute("employeeList", list);

        // Forward
        request.getRequestDispatcher("payroll_view.jsp").forward(request, response);
    }
}