<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Register Subject</title>
</head>
<body>

    <h2>Register Subject</h2>

    <form action="SubjectServlet" method="post">

        <input type="hidden" name="action" value="insert">

        Subject Code:
        <input type="text" name="subjectCode" required>
        <br><br>

        Subject Name:
        <input type="text" name="subjectName" required>
        <br><br>

        Credit Hour:
        <input type="number" name="creditHour" required>
        <br><br>

        <input type="submit" value="Submit">

    </form>

    <br>

    <a href="SubjectServlet">Back</a>

</body>
</html>