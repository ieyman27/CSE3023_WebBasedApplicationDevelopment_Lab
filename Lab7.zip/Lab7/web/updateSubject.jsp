<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="com.lab.bean.Subject" %>

<%
Subject subject = (Subject) request.getAttribute("subject");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Update Subject</title>
</head>
<body>

<h2>Update Subject</h2>

<form action="SubjectServlet" method="get">

    <input type="hidden" name="action" value="update">

    <input type="hidden" name="subjectId"
           value="<%= subject.getSubjectId() %>">

    Subject Code:
    <input type="text" name="subjectCode"
           value="<%= subject.getSubjectCode() %>">

    <br><br>

    Subject Name:
    <input type="text" name="subjectName"
           value="<%= subject.getSubjectName() %>">

    <br><br>

    Credit Hour:
    <input type="number" name="creditHour"
           value="<%= subject.getCreditHour() %>">

    <br><br>

    <input type="submit" value="Update">

</form>

</body>
</html>