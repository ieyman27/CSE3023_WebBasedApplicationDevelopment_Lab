<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Home</title>
</head>
<body>

<h1>Welcome to Student Subject Management System</h1>

<a href="SubjectServlet">View Subjects</a>

</body>
</html>