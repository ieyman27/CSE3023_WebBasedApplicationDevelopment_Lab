<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>

<%@ page import="java.util.*" %>
<%@ page import="com.lab.bean.Subject" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Subjects</title>
</head>
<body>

    <h2>Subject List</h2>

    <a href="SubjectServlet?action=new">Add New Subject</a>

    <br><br>

    <table border="1" cellpadding="10">

        <tr>
            <th>ID</th>
            <th>Subject Code</th>
            <th>Subject Name</th>
            <th>Credit Hour</th>
            <th>Action</th>
        </tr>

        <%
            List<Subject> listSubject =
                (List<Subject>) request.getAttribute("listSubject");

            if (listSubject != null && !listSubject.isEmpty()) {

                for (Subject s : listSubject) {
        %>

        <tr>
            <td><%= s.getSubjectId() %></td>
            <td><%= s.getSubjectCode() %></td>
            <td><%= s.getSubjectName() %></td>
            <td><%= s.getCreditHour() %></td>

            <td>
                <a href="SubjectServlet?action=edit&id=<%= s.getSubjectId() %>">
                    Edit
                </a>

                |

                <a href="SubjectServlet?action=delete&id=<%= s.getSubjectId() %>">
                    Delete
                </a>
            </td>
        </tr>

        <%
                }
            } else {
        %>

        <tr>
            <td colspan="5">No subjects available</td>
        </tr>

        <%
            }
        %>

    </table>

</body>
</html>