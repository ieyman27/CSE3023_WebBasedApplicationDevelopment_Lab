package com.lab.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.lab.bean.Subject;
import com.lab.dao.SubjectDAO;

@WebServlet("/SubjectServlet")
public class SubjectServlet extends HttpServlet {

    SubjectDAO dao = new SubjectDAO();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action == null) {
            listSubject(request, response);
        }
        else if (action.equals("new")) {

            request.getRequestDispatcher("registerSubject.jsp")
                   .forward(request, response);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action.equals("insert")) {

            Subject s = new Subject();

            s.setSubjectCode(request.getParameter("subjectCode"));
            s.setSubjectName(request.getParameter("subjectName"));
            s.setCreditHour(
                Integer.parseInt(
                    request.getParameter("creditHour")
                )
            );

            dao.insertSubject(s);

            listSubject(request, response);
        }
    }

    private void listSubject(HttpServletRequest request,
                             HttpServletResponse response)
            throws ServletException, IOException {

        List<Subject> listSubject = dao.getAllSubjects();

        request.setAttribute("listSubject", listSubject);

        request.getRequestDispatcher("viewSubjects.jsp")
               .forward(request, response);
    }
}