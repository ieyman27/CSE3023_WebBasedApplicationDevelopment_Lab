package com.lab.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lab.bean.Subject;

public class SybjectDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/student_subject_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_SUBJECT_SQL =
            "INSERT INTO subject(subject_code, subject_name, credit_hour) VALUES (?, ?, ?)";

    private static final String SELECT_ALL_SUBJECTS =
            "SELECT * FROM subject";

    private static final String DELETE_SUBJECT_SQL =
            "DELETE FROM subject WHERE subject_id = ?";

    private static final String UPDATE_SUBJECT_SQL =
            "UPDATE subject SET subject_code=?, subject_name=?, credit_hour=? WHERE subject_id=?";

    private static final String SELECT_SUBJECT_BY_ID =
            "SELECT * FROM subject WHERE subject_id=?";

    protected Connection getConnection() {
        Connection connection = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return connection;
    }

    // CREATE
    public void insertSubject(Subject subject) {

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SUBJECT_SQL)) {

            preparedStatement.setString(1, subject.getSubjectCode());
            preparedStatement.setString(2, subject.getSubjectName());
            preparedStatement.setInt(3, subject.getCreditHour());

            preparedStatement.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // READ
    public List<Subject> selectAllSubjects() {

        List<Subject> subjects = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_SUBJECTS)) {

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {

                int id = rs.getInt("subject_id");
                String code = rs.getString("subject_code");
                String name = rs.getString("subject_name");
                int credit = rs.getInt("credit_hour");

                subjects.add(new Subject(code, name, credit));
                subjects.get(subjects.size() - 1).setSubjectId(id);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return subjects;
    }

    // GET SUBJECT BY ID
    public Subject selectSubject(int id) {

        Subject subject = null;

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SUBJECT_BY_ID)) {

            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String code = rs.getString("subject_code");
                String name = rs.getString("subject_name");
                int credit = rs.getInt("credit_hour");

                subject = new Subject(code, name, credit);
                subject.setSubjectId(id);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return subject;
    }

    // UPDATE
    public boolean updateSubject(Subject subject) {

        boolean rowUpdated = false;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SUBJECT_SQL)) {

            statement.setString(1, subject.getSubjectCode());
            statement.setString(2, subject.getSubjectName());
            statement.setInt(3, subject.getCreditHour());
            statement.setInt(4, subject.getSubjectId());

            rowUpdated = statement.executeUpdate() > 0;
              } catch (Exception e) {
            e.printStackTrace();
        }

        return rowUpdated;
    }

    // DELETE
    public boolean deleteSubject(int id) {

        boolean rowDeleted = false;

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SUBJECT_SQL)) {

            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rowDeleted;
    }
}