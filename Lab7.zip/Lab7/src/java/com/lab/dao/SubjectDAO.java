package com.lab.dao;

import com.lab.bean.Subject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAO {

    // INSERT SUBJECT
    public void insertSubject(Subject s) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql =
                "INSERT INTO subject(subjectCode, subjectName, creditHour) VALUES (?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, s.getSubjectCode());
            ps.setString(2, s.getSubjectName());
            ps.setInt(3, s.getCreditHour());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // SELECT ALL SUBJECTS
    public List<Subject> getAllSubjects() {

        List<Subject> list = new ArrayList<>();

        try {

            Connection conn = DBConnection.getConnection();

            String sql = "SELECT * FROM subject";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Subject s = new Subject();

                s.setSubjectId(rs.getInt("subjectId"));
                s.setSubjectCode(rs.getString("subjectCode"));
                s.setSubjectName(rs.getString("subjectName"));
                s.setCreditHour(rs.getInt("creditHour"));

                list.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // SELECT ONE SUBJECT
    public Subject selectSubject(int id) {

        Subject s = null;

        try {

            Connection conn = DBConnection.getConnection();

            String sql =
                "SELECT * FROM subject WHERE subjectId=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                s = new Subject();

                s.setSubjectId(rs.getInt("subjectId"));
                s.setSubjectCode(rs.getString("subjectCode"));
                s.setSubjectName(rs.getString("subjectName"));
                s.setCreditHour(rs.getInt("creditHour"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return s;
    }

    // UPDATE SUBJECT
    public void updateSubject(Subject s) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql =
                "UPDATE subject SET subjectCode=?, subjectName=?, creditHour=? WHERE subjectId=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, s.getSubjectCode());
            ps.setString(2, s.getSubjectName());
            ps.setInt(3, s.getCreditHour());
            ps.setInt(4, s.getSubjectId());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // DELETE SUBJECT
    public void deleteSubject(int id) {

        try {

            Connection conn = DBConnection.getConnection();

            String sql =
                "DELETE FROM subject WHERE subjectId=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // OPTIONAL METHOD
    public List<Subject> selectAllSubjects() {
        return getAllSubjects();
    }
}