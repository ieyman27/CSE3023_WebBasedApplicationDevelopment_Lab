package com.lab.bean;

public class Subject {

    private int subjectId;
    private String subjectCode;
    private String subjectName;
    private int creditHour;

    public Subject() {
    }

    public Subject(String subjectCode, String subjectName, int creditHour) {
        this.subjectCode = subjectCode;
        this.subjectName = subjectName;
        this.creditHour = creditHour;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public int getCreditHour() {
        return creditHour;
    }

    public void setCreditHour(int creditHour) {
        this.creditHour = creditHour;
    }
}
