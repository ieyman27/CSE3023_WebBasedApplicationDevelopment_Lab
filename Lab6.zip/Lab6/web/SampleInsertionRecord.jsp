<%-- 
    Document   : SampleInsertionRecord
    Created on : 12 May 2026
    Author     : User
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Sample Insertion</title>

    <style>

        body{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 40px;
        }

        .container{
            background: white;
            padding: 25px;
            border-radius: 10px;
            width: 700px;
            margin: auto;
            box-shadow: 0px 0px 10px gray;
        }

        h1{
            color: #003366;
        }

        p{
            padding: 10px;
            background-color: #e8f5e9;
            border-left: 5px solid green;
        }

        .step{
            color: blue;
            font-weight: bold;
            margin-top: 10px;
        }

        .success{
            color: green;
            font-weight: bold;
        }

        .error{
            color: red;
            font-weight: bold;
        }

    </style>

</head>

<body>

<div class="container">

<h1>
    Lab 6 - Task 1 - Sample Insertion records into MySQL through JSP page
</h1>

<%

Connection myConnection = null;
PreparedStatement myPS = null;

try {

    int result;

    // Step 1 : Load JDBC Driver
    Class.forName("com.mysql.cj.jdbc.Driver");

%>

<p class="step">
    Step 1: MySQL Driver Loaded Successfully!
</p>

<%

    // Step 2 : Connect Database

    String url =
        "jdbc:mysql://localhost:3307/cse3023";

    myConnection = DriverManager.getConnection(
        url,
        "root",
        ""
    );

%>

<p class="step">
    Step 2: Database Connected Successfully!
</p>

<%

    // Step 3 : Prepare SQL Statement

    String sInsertQry =
        "INSERT INTO FirstTable(message) VALUES(?)";

    myPS =
        myConnection.prepareStatement(sInsertQry);

%>

<p class="step">
    Step 3: Prepared Statement Created!
</p>

<%

    // Step 4 : Insert Record

    String name =
        "Welcome to access MySQL database with JSP";

    myPS.setString(1, name);

    result = myPS.executeUpdate();

%>

<p class="step">
    Step 4: Performing Record Insertion!
</p>

<%

    if(result > 0){

%>

<p class="success">
    Record inserted successfully!
</p>

<p>
    The record:
    <b><%= name %></b>
    has been successfully inserted into the database.
</p>

<%

    }

}
catch(Exception e){

%>

<p class="error">
    ERROR:
    <%= e.getMessage() %>
</p>

<%

}
finally {

    // Step 5 : Close Connection

    if(myPS != null)
        myPS.close();

    if(myConnection != null)
        myConnection.close();

}

%>

<p class="step">
    Step 5: Database Connection Closed!
</p>

</div>

</body>
</html>