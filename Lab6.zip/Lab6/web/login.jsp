<%-- 
    Document   : Login
    Created on : 12 May 2026
    Author     : User
--%>

<%
String message = request.getParameter("msg");
%>

<!DOCTYPE html>
<html>

<head>
    <title>User Login</title>

    <style>

        body{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container{
            width: 400px;
            background-color: white;
            margin: 80px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
        }

        h2{
            text-align: center;
            color: #003366;
            margin-bottom: 25px;
        }

        table{
            width: 100%;
        }

        td{
            padding: 10px;
        }

        input[type="text"],
        input[type="password"]{

            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        input[type="submit"],
        input[type="reset"]{

            width: 48%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 15px;
            cursor: pointer;
        }

        input[type="submit"]{
            background-color: #007bff;
            color: white;
        }

        input[type="submit"]:hover{
            background-color: #0056b3;
        }

        input[type="reset"]{
            background-color: #dc3545;
            color: white;
            margin-left: 10px;
        }

        input[type="reset"]:hover{
            background-color: #a71d2a;
        }

        .button-container{
            text-align: center;
        }

        .error-message{
            color: red;
            text-align: center;
            font-weight: bold;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

<div class="container">

    <h2>Login Form</h2>

    <%
    if(message != null) {
    %>

        <p class="error-message">
            <%= message %>
        </p>

    <%
    }
    %>

    <form action="doLogin.jsp" method="post">

        <table>

            <tr>
                <td>Username :</td>
                <td>
                    <input type="text"
                           name="username"
                           required>
                </td>
            </tr>

            <tr>
                <td>Password :</td>
                <td>
                    <input type="password"
                           name="password"
                           required>
                </td>
            </tr>

            <tr>
                <td colspan="2" class="button-container">

                    <input type="submit" value="Login">

                    <input type="reset" value="Cancel">

                </td>
            </tr>

        </table>

    </form>

</div>

</body>
</html>