<%@page import="java.sql.*"%>

<!DOCTYPE html>
<html>
<head>
    <title>Process User</title>

    <style>

        body{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container{
            width: 500px;
            margin: 80px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
            text-align: center;
        }

        h2{
            color: #003366;
        }

        .success{
            color: green;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .error{
            color: red;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        a{
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 15px;
        }

        a:hover{
            background-color: #0056b3;
        }

    </style>

</head>

<body>

<div class="container">

<h2>User Registration Status</h2>

<%

String username = request.getParameter("username");
String password = request.getParameter("password");
String firstname = request.getParameter("firstname");
String lastname = request.getParameter("lastname");

Connection conn = null;
PreparedStatement ps = null;

try {

    // Load MySQL Driver
    Class.forName("com.mysql.cj.jdbc.Driver");

    // Create Connection
    conn = DriverManager.getConnection(
        "jdbc:mysql://localhost:3307/CSE3023",
        "root",
        ""
    );

    // SQL Query
    String sql =
        "INSERT INTO userprofile VALUES (?, ?, ?, ?)";

    ps = conn.prepareStatement(sql);

    ps.setString(1, username);
    ps.setString(2, password);
    ps.setString(3, firstname);
    ps.setString(4, lastname);

    int result = ps.executeUpdate();

    if(result > 0) {

%>

        <p class="success">
            User registered successfully!
        </p>

        <a href="login.jsp">
            Login Here
        </a>

<%

    }
    else {

%>

        <p class="error">
            Registration Failed!
        </p>

<%

    }

}
catch(Exception e) {

%>

    <p class="error">
        Error :
        <%= e.getMessage() %>
    </p>

<%

}
finally {

    if(ps != null)
        ps.close();

    if(conn != null)
        conn.close();
}
%>

</div>

</body>
</html>