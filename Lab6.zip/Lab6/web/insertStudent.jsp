<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Register Student</title>
</head>
<body>

    <h2>Student Registration Form</h2>

    <form action="processStudent.jsp" method="post">

        <table>
            <tr>
                <td>Student No :</td>
                <td>
                    <input type="text" name="stuno" required>
                </td>
            </tr>

            <tr>
                <td>Name :</td>
                <td>
                    <input type="text" name="name" required>
                </td>
            </tr>

            <tr>
                <td>Program :</td>
                <td>
                    <select name="program">
                        <option value="Diploma">Diploma</option>
                        <option value="Degree">Degree</option>
                        <option value="Master">Master</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td colspan="2">
                    <input type="submit" value="Submit">
                    <input type="reset" value="Cancel">
                </td>
            </tr>
        </table>

    </form>

</body>
</html>