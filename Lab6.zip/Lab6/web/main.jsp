<%-- 
    Document   : main
    Created on : 12 May 2026
    Author     : User
--%>

<!DOCTYPE html>
<html>

<head>
    <title>Main Page</title>

    <style>

        body{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container{
            width: 500px;
            background-color: white;
            margin: 80px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
            text-align: center;
        }

        h2{
            color: #003366;
            margin-bottom: 25px;
        }

        .info-box{
            background-color: #e8f5e9;
            border-left: 5px solid green;
            padding: 15px;
            margin-bottom: 15px;
            text-align: left;
            border-radius: 5px;
        }

        .label{
            font-weight: bold;
            color: #003366;
        }

        .logout-btn{
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .logout-btn:hover{
            background-color: #a71d2a;
        }

    </style>

</head>

<body>

<div class="container">

    <h2>Welcome to the System</h2>

    <div class="info-box">

        <p>
            <span class="label">Username :</span>
            <%= session.getAttribute("username") %>
        </p>

    </div>

    <div class="info-box">

        <p>
            <span class="label">First Name :</span>
            <%= session.getAttribute("firstname") %>
        </p>

    </div>

    <div class="info-box">

        <p>
            <span class="label">Last Name :</span>
            <%= session.getAttribute("lastname") %>
        </p>

    </div>

    <a href="login.jsp" class="logout-btn">
        Logout
    </a>

</div>

</body>
</html>