<%-- 
    Document   : doLogin
    Created on : 12 May 2026, 3:17:32?pm
    Author     : User
--%>

<%@page import="java.sql.*"%>

<%

String username = request.getParameter("username");
String password = request.getParameter("password");

Connection conn = null;
PreparedStatement ps = null;
ResultSet rs = null;

try {

    Class.forName("com.mysql.jdbc.Driver");

    conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3307/CSE3023",
            "root",
            ""
    );

    // ? ADD ON COLLATE HERE
    String sql =
        "SELECT * FROM userprofile " +
        "WHERE username COLLATE utf8mb4_bin = ? " +
        "AND password COLLATE utf8mb4_bin  = ?";

    ps = conn.prepareStatement(sql);

    ps.setString(1, username);
    ps.setString(2, password);

    rs = ps.executeQuery();

    if (rs.next()) {

        session.setAttribute("username", rs.getString("username"));
        session.setAttribute("firstname", rs.getString("firstname"));
        session.setAttribute("lastname", rs.getString("lastname"));

        response.sendRedirect("main.jsp");

    } else {

        response.sendRedirect("login.jsp?msg=Invalid username or password..!");
    }

} catch (Exception e) {

    out.println("Error : " + e);

} finally {

    if (rs != null) rs.close();
    if (ps != null) ps.close();
    if (conn != null) conn.close();
}
%>